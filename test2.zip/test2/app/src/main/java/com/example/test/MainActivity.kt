package com.example.test

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    lateinit var name : EditText
    lateinit var location : EditText
    lateinit var btn : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        name = findViewById(R.id.name)
        location = findViewById(R.id.loc)
        btn = findViewById(R.id.button)
        btn.setOnClickListener {
            val name = name.text.toString()
            val loc = location.text.toString()
            Toast.makeText(applicationContext, "[ $name , $loc ]", Toast.LENGTH_SHORT).show()
        }
    }
}